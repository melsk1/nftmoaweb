export { default as WalletCreateAgree } from './agree';
export { default as WalletCreatePassword } from './password';
