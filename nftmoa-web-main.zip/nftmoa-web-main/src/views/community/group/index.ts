export { default as CommunityGroupList } from './list';
