export const BOARD_LIST = {
  total: 99,
  data: [
    {
      id: 0,
      title: 'Chill Heaven | Social, Anime, Egirls, Gaming, Emotes, Fun, Active VCs, Nitors, emejis, NFT',
      desc: '#1 Chil Community  # 😀400 BEST Emtes  # 🩸Nitro Giveaways  #Active Chats👀  #Social🙏',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169033632-b7c71789-7437-4601-84ec-d064bafd5f50.png',
      online: 213,
      members: 1001
    },
    {
      id: 1,
      title: 'NFTs World | #1NFT Community, Metaverse, Crypto, Blockchain, Collabs, Advertise, Marketing',
      desc: 'The largest NFT community for everyone to share their NFTs, find new projects and The largest NFT community for everyone to share their NFTs, find new projects and',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032476-d0ee7fa7-948a-42f8-933c-1772cd97cdb9.png',
      online: 213,
      members: 1001
    },
    {
      id: 2,
      title: 'Rarity Sniper | NFT',
      desc: 'Rarity Sniper is the best way to check the rarity of your NFTs',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032519-944aabb5-3dac-4788-8bfb-bee5af46c32d.png',
      online: 213,
      members: 1001
    },
    {
      id: 3,
      title: 'Slotie NFT👅',
      desc: '🕶️ Slotie NFT is a club of classy memners that reinvent online gaming🎃🎃',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032545-66b0c5ed-f008-4967-8736-53238229d96e.png',
      online: 213,
      members: 1001
    },
    {
      id: 4,
      title: 'SIDUS-The City of NFT Heroes',
      desc: 'Next-generation AAA + Browser gaming metaverse. Play to earn, rule the Sidus Station with your Guild, Fight for Victory!',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032559-d434694e-641d-4e10-ba78-daf64bd9bd32.png',
      online: 213,
      members: 1001
    },
    {
      id: 5,
      title: 'r/NFT Community',
      desc: 'f/NFT Community is the offcial nftnoa server fot the r/NFT subreddit join now and let’s ...',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032575-e218490a-6cd3-4a4d-b823-551c882c684b.png',
      online: 213,
      members: 1001
    },
    {
      id: 6,
      title: 'KriptoKrazed | NFT | Crypto',
      desc: 'KriptoKrazed is commlited to creating high quality NFt’s for you to enjoy',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032599-466edbd9-6c7e-4392-8e54-ba69af33e12c.png',
      online: 213,
      members: 1001
    },
    {
      id: 7,
      title: 'NFT Worlds',
      desc: 'Official server of the NFTWorlds community!',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032647-ab4bf210-8180-41ef-a5bd-0f5d527070a0.png',
      online: 213,
      members: 1001
    },
    {
      id: 8,
      title: 'NFT.com',
      desc: 'NFTSTAR is a fan community within a premium NFT marketplace featuring global stars and their stories',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032622-f87fb376-0e7f-4d15-80cd-29dd86585114.png',
      online: 213,
      members: 1001
    },
    {
      id: 9,
      title: 'SIDUS-The City of NFT Heroes',
      desc: 'Next-generation AAA + Browser gaming metaverse. Play to earn, rule the Sidus Station with your Guild, Fight for Victory!',
      thumbnail: 'https://user-images.githubusercontent.com/45615584/169032670-a551130d-60a0-4519-a1cb-461078108878.png',
      online: 213,
      members: 1001
    }
  ]
};

export const BOARD_DETAIL = {
  uid: 0,
  title: 'SIDUS - The city of NFT Heroes',
  bg: 'https://user-images.githubusercontent.com/45615584/169082872-440787a7-09dc-4e7e-824b-c692749e6935.png',
  welcome: 'Welcome to SIDUS - The city of NFT Heroes',
  profileImage: 'https://user-images.githubusercontent.com/45615584/169082917-eede0f4d-9a51-4174-815c-543e82e4b998.png',
  author: 'Beanzoffcial',
  level: 'Owner',
  group: [
    {
      gid: 10,
      name: 'announcements'
    },
    { gid: 11, name: 'Rules', isPrivate: true },
    { gid: 12, name: 'about' },
    { gid: 13, name: 'verify-here' },
    { gid: 41, name: 'verification-help' }
  ],
  online: 213,
  members: 1001
};

export const CHANNEL_EDIT = {
  cname: 'NFT World by justin'
};

export const SEARCH_TAG_LIST = [
  { id: 0, tag: 'NFT' },
  { id: 1, tag: 'Cryptocurrency' },
  { id: 2, tag: 'gaming' },
  { id: 3, tag: 'investing' }
];

export const CHANNEL_LIST = [
  {
    id: 0,
    profileImage: 'https://user-images.githubusercontent.com/45615584/169035463-83fa2086-c830-4965-9f47-393b96124f60.png',
    channelName: 'aaa'
  },
  {
    id: 1,
    profileImage: 'https://user-images.githubusercontent.com/45615584/169035485-9d30cf4b-273b-4ac1-b982-225d2daadcc0.png',
    msgCount: 100,
    channelName: 'bbb'
  }
];

export const CHANNEL_CTG = [
  {
    id: 0,
    thumbnail: 'https://user-images.githubusercontent.com/45615584/169043198-5cbc8ee0-215d-4340-85d1-34e850b8861b.png',
    name: 'Create My Own'
  },
  {
    id: 1,
    thumbnail: 'https://user-images.githubusercontent.com/45615584/169043220-a4d514f1-150c-416b-871a-ddee499466a7.png',
    name: 'Friends'
  },
  {
    id: 2,
    thumbnail: 'https://user-images.githubusercontent.com/45615584/169043234-148871c3-72fd-494a-bd13-0b4efdbc310b.png',
    name: 'Study Group'
  },
  {
    id: 3,
    thumbnail: 'https://user-images.githubusercontent.com/45615584/169043242-fa138296-680f-4b76-aceb-3ebcb0592b15.png',
    name: 'Community Group'
  },
  {
    id: 4,
    thumbnail: 'https://user-images.githubusercontent.com/45615584/169043249-ae0d2459-a393-446f-af3d-07b2fd14dac5.png',
    name: 'Artist & Creators'
  }
];

export const GROUP_LIST = {
  gid: 513,
  name: 'NFT World by justin'
};

export const COMMENT_LIST = [
  {
    id: 0,
    type: 'WELCOME',
    name: 'nftmoa',
    timestamp: '1 min ago',
    content: `Welcom to NFT World by justin. 
This is your brand new, shiny channel, Here are some steps to help you get started. For more, Check out our Getting Started guide`,
    avatar: 'https://user-images.githubusercontent.com/45615584/169656978-d8be8d32-436b-43c1-ae98-9c47d2be47c4.png',
    datetime: 'May 5, 2022'
  },
  {
    id: 1,
    type: 'COMMENT',
    name: 'poe',
    timestamp: '1 min ago',
    content: `welcome in this group!`,
    avatar: 'https://user-images.githubusercontent.com/45615584/170819059-4517b835-8b30-423c-af08-1ad6a353433c.png',
    datetime: 'May 5, 2022'
  }
];

export const INVITE_LIST = [
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169658855-c5ab2358-ad56-490f-9d14-77e059e0bd49.png',
    name: 'bynoWRLD',
    isInvite: false
  },
  {
    id: 1,
    avatar: 'https://user-images.githubusercontent.com/45615584/169658859-a1915cd3-15c4-4c73-92df-12cda6a17ee7.png',
    name: 'nifyorca',
    isInvite: false
  },
  {
    id: 2,
    avatar: 'https://user-images.githubusercontent.com/45615584/169658864-730196f5-f654-400a-9aeb-bf4071fe3a51.png',
    name: 'Ludachris1',
    isInvite: false
  },
  {
    id: 3,
    avatar: 'https://user-images.githubusercontent.com/45615584/169658903-85cd367c-d369-41da-9eb3-69d91221bd55.png',
    name: 'To the moon',
    isInvite: false
  }
];

export const OWNER = {
  id: 0,
  avatar: 'https://user-images.githubusercontent.com/45615584/169658865-fe55eb52-dab7-4dc6-b9b7-c98efc4e5fcf.png',
  name: 'Beaznofficial'
};

export const ONLINE_LIST = [
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660845-68bee684-aaf3-413c-bbd6-639b3ec2f4c5.png',
    name: 'Justin'
  },
  {
    id: 0,
    avatar: '',
    name: 'bynoWRLD'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169658855-c5ab2358-ad56-490f-9d14-77e059e0bd49.png',
    name: 'nifyorca'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169658859-a1915cd3-15c4-4c73-92df-12cda6a17ee7.png',
    name: 'Ludachris1'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660843-70b68a78-2f91-4c37-86ed-4e73ca56f9b3.png',
    name: 'RCTech | Breedania'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169658903-85cd367c-d369-41da-9eb3-69d91221bd55.png',
    name: 'To the moon'
  }
];

export const OFFLINE_LIST = [
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660854-20dcd61d-11cf-4260-b750-b8a078dc3e59.png',
    name: 'Hyper'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660851-9463f147-f073-4a78-a6b3-7fba27816f77.png',
    name: 'dynamiceric'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660851-9463f147-f073-4a78-a6b3-7fba27816f77.png',
    name: 'iridum191'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660851-9463f147-f073-4a78-a6b3-7fba27816f77.png',
    name: 'MAJE'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660851-9463f147-f073-4a78-a6b3-7fba27816f77.png',
    name: 'Lskfee'
  },
  {
    id: 0,
    avatar: 'https://user-images.githubusercontent.com/45615584/169660849-7dc2db8e-d4cd-4a76-8c6c-d31a62aaabae.png',
    name: 'peakoman'
  }
];

export const MSG_COMMUNITY_LIST = [
  {
    groupName: 'NFT World by Justin',
    total: 8,
    list: [
      {
        id: 0,
        name: 'justin',
        introComment: 'NFT World by justin.',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170413789-8b4b2560-1f4f-4d37-a05f-4889d5700a8b.png',
        isOnline: true,
        chatTotal: 2
      },
      {
        id: 1,
        name: 'bynoWRLD',
        introComment: 'NFT World by justin.',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828282-a0aadb24-74c5-4f3e-a66a-927599a68759.png',
        isOnline: true,
        chatTotal: 4
      },
      {
        id: 0,
        name: 'nifyorca',
        introComment: 'NFT World by justin.',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828279-76f1aae6-839a-402b-b4ab-d856203336ec.png',
        isOnline: true,
        chatTotal: 2
      }
    ]
  },
  {
    groupName: 'Sandbox’s LANDs',
    total: 6,
    list: [
      {
        id: 1,
        name: 'Smircs',
        introComment: 'Sandbox’s LANDS',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170830121-1d26fd8e-c699-4767-b24c-1c028c000b92.png',
        isOnline: true,
        chatTotal: 4
      },
      {
        id: 0,
        name: 'bynoWRLD',
        introComment: 'Sandbox’s LANDS',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828282-a0aadb24-74c5-4f3e-a66a-927599a68759.png',
        isOnline: true,
        chatTotal: 2
      }
    ]
  },
  {
    groupName: 'The NFTeams',
    total: 8,
    list: [
      {
        id: 0,
        name: 'Smircs',
        introComment: 'The NFTeams',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170829964-f9a4cce1-a867-4178-a60c-a9cd3f2f7090.png',
        isOnline: true,
        chatTotal: 2
      },
      {
        id: 1,
        name: 'bynoWRLD',
        introComment: 'The NFTeams',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170830075-55f41f76-ecd5-4947-bb7f-206c2094bca8.png',
        isOnline: true,
        chatTotal: 4
      },
      {
        id: 0,
        name: 'nifyorca',
        introComment: 'The NFTeams',
        thumbUrl: 'https://user-images.githubusercontent.com/45615584/170830078-6a1add0e-e7c4-4cbb-a157-5bf6ca2dd47e.png',
        isOnline: true,
        chatTotal: 2
      }
    ]
  }
];

export const MSG_DIRECT_LIST = [
  {
    id: 0,
    name: 'Smircs',
    introComment: '-',
    thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828205-85364216-b6b2-42e3-9497-a54baa1c2aaa.png',
    isOnline: true,
    chatTotal: 2
  },
  {
    id: 1,
    name: 'bynoWRLD',
    introComment: `Sandbox's LANDs`,
    thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828282-a0aadb24-74c5-4f3e-a66a-927599a68759.png',
    isOnline: true,
    chatTotal: 4
  },
  {
    id: 2,
    name: 'nifyorca',
    introComment: `SINS`,
    thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828279-76f1aae6-839a-402b-b4ab-d856203336ec.png',
    isOnline: true,
    chatTotal: 2
  },
  {
    id: 3,
    name: 'Ludachris1',
    introComment: `adidas Originals: Into the Metaverse`,
    thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828288-7d1bb7e9-80a5-4743-a132-f7e19c776d3a.png',
    isOnline: false,
    chatTotal: 1
  },
  {
    id: 4,
    name: 'RCTech | Breedania',
    introComment: `Slotie`,
    thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828293-f24763eb-c59c-4125-8d8e-1c986c4dfda9.png',
    isOnline: false,
    chatTotal: 9
  },
  {
    id: 5,
    name: 'To the moon',
    introComment: `-`,
    thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828295-7205437f-b478-4d68-b6dd-012d176ed2a4.png',
    isOnline: true,
    chatTotal: 1
  },
  {
    id: 6,
    name: 'Beaznofficial',
    introComment: `Welcom to NFT World by justin.`,
    thumbUrl: 'https://user-images.githubusercontent.com/45615584/170828298-36cf188a-dc11-4678-aadf-e593c2ed07d6.png',
    isOnline: false,
    chatTotal: 1
  }
];

export const MSG_ROOM_LIST: any = {
  justin: {
    name: 'justin',
    introComment: 'NFT World by justin.',
    isOnline: true,
    data: [
      {
        id: 0,
        type: 'WELCOME',
        name: 'justin',
        introComment: 'NFT World bt justin.',
        avatar: 'https://user-images.githubusercontent.com/45615584/170413789-8b4b2560-1f4f-4d37-a05f-4889d5700a8b.png',
        content: 'Hello, bynoWRLDWelcome to NFT World by Justin'
      },
      {
        id: 1,
        name: 'justin',
        type: 'WELCOME',
        introComment: 'NFT World bt justin.',
        avatar: 'https://user-images.githubusercontent.com/45615584/170413789-8b4b2560-1f4f-4d37-a05f-4889d5700a8b.png',
        content: `Hello, bynoWRLD
      Welcome to NFT World by Justin
      #START
      `
      }
    ]
  },
  Smircs: {
    name: 'Smircs',
    isOnline: true,
    data: [
      {
        id: 0,
        name: 'Simircs',
        avatar: 'https://user-images.githubusercontent.com/45615584/170828205-85364216-b6b2-42e3-9497-a54baa1c2aaa.png',
        timestamp: '1hr ago',
        content: `Hello, Justin
        Son Heung-min is aiming for a chance to become the top scorer at Tottenham Stadium today!🚀 🚀 🚀
        Please cheer for Son Heung-min to become the top scorer in the discode General-chat of the game tomorrow morning.`
      },
      {
        id: 1,
        name: 'Simircs',
        avatar: 'https://user-images.githubusercontent.com/45615584/170828205-85364216-b6b2-42e3-9497-a54baa1c2aaa.png',
        timestamp: '1hr ago',
        content: `⚽ Holders, thank you for waiting. All Son Heung-min NFT holders will airdrop their holder-only premium player cards in the P2E soccer game "Metagol," which is scheduled to be released in the second quarter.

        Each unique card will be divided into rarity aspects and will help you get more rewards both inside and outside the game.
        
        💚 Airdrop will be held before the game is released.
        
        Please look forward to the upcoming news and AirDrop. ✨
      `
      }
    ]
  },
  bynoWRLD: {
    name: 'bynoWRLD',
    introComment: 'NFT World by justin.',
    isOnline: true,
    data: [
      {
        id: 0,
        name: 'bynoWRLD',
        avatar: 'https://user-images.githubusercontent.com/45615584/170828282-a0aadb24-74c5-4f3e-a66a-927599a68759.png',
        timestamp: '1hr ago',
        content: `Hello, Justin
        Son Heung-min is aiming for a chance to become the top scorer at Tottenham Stadium today!🚀 🚀 🚀
        Please cheer for Son Heung-min to become the top scorer in the discode General-chat of the game tomorrow morning.`
      },
      {
        id: 1,
        name: 'bynoWRLD',
        avatar: 'https://user-images.githubusercontent.com/45615584/170828282-a0aadb24-74c5-4f3e-a66a-927599a68759.png',
        timestamp: '1hr ago',
        content: `⚽ Holders, thank you for waiting. All Son Heung-min NFT holders will airdrop their holder-only premium player cards in the P2E soccer game "Metagol," which is scheduled to be released in the second quarter.

        Each unique card will be divided into rarity aspects and will help you get more rewards both inside and outside the game.
        
        💚 Airdrop will be held before the game is released.
        
        Please look forward to the upcoming news and AirDrop. ✨
      `
      }
    ]
  }
};

export const INVITE = {
  from: 'justin',
  avatar: 'https://user-images.githubusercontent.com/45615584/170413789-8b4b2560-1f4f-4d37-a05f-4889d5700a8b.png',
  groupName: 'NFT World by justin',
  online: 1,
  members: 1,
  isAccepted: false
};
