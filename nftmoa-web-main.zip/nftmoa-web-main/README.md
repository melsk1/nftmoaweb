# NFT MOA

피그마: https://www.figma.com/file/4k1qSVd2h1u6iBR9anCvW5/MOA?node-id=105%3A7090

오른쪽에 있는게 확정된 디자인 
